Translations have moved to
https://translate.wordpress.org/projects/wp-plugins/wp-statistics
Please visit https://wp-statistics.com/translations/ to help translation.

Thank you for your contribution.